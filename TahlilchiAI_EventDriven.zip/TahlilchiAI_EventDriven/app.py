# app.py
from flask import Flask, render_template, request, flash
import logging
from threading import Thread
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'tahlilchi-ai-event-secret'

# Logging sozlamalari
logging.basicConfig(
    filename='events.log',
    level=logging.INFO,
    format='%(asctime)s - %(message)s'
)


# Voqea ishlovchisi
class EventHandler:
    @staticmethod
    def log_event(message):
        """Voqeani asinxron tarzda log fayliga yozish."""

        def process_event():
            logging.info(message)

        Thread(target=process_event).start()


# Marshrutlar
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Tugma bosilganda voqea ishga tushadi
        event_handler = EventHandler()
        event_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        event_handler.log_event(f"Analysis triggered by user at {event_time}")
        flash('Analysis event triggered successfully!', 'success')

    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)