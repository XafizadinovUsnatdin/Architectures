# app.py
from flask import Flask, request, render_template, redirect, url_for, flash
import sqlite3
from sqlite3 import Error

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Required for flash messages


# Data Access Layer
class BookDatabase:
    def __init__(self, db_file='books.db'):
        self.db_file = db_file
        self._initialize_database()

    def _initialize_database(self):
        """Initialize the database and ensure the correct schema."""
        try:
            with self._get_connection() as conn:
                # Create table if it doesn't exist
                conn.execute('''CREATE TABLE IF NOT EXISTS books (
                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                title TEXT NOT NULL,
                                author TEXT NOT NULL)''')
                # Check if isbn column exists, add it if not (without UNIQUE initially)
                cursor = conn.execute("PRAGMA table_info(books)")
                columns = [col[1] for col in cursor.fetchall()]
                if 'isbn' not in columns:
                    conn.execute('ALTER TABLE books ADD COLUMN isbn TEXT')
                conn.commit()
        except Error as e:
            print(f"Error initializing database: {e}")

    def _get_connection(self):
        """Create a database connection."""
        return sqlite3.connect(self.db_file, check_same_thread=False)

    def get_all_books(self):
        """Retrieve all books from the database."""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute('SELECT id, title, author, isbn FROM books')
                return [{'id': row[0], 'title': row[1], 'author': row[2], 'isbn': row[3]} for row in cursor.fetchall()]
        except Error as e:
            print(f"Error fetching books: {e}")
            return []

    def add_book(self, title, author, isbn):
        """Add a new book to the database."""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute(
                    'INSERT INTO books (title, author, isbn) VALUES (?, ?, ?)',
                    (title, author, isbn)
                )
                conn.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Error adding book: {e}")
            return None

    def update_book(self, book_id, title, author, isbn):
        """Update an existing book."""
        try:
            with self._get_connection() as conn:
                conn.execute(
                    'UPDATE books SET title = ?, author = ?, isbn = ? WHERE id = ?',
                    (title, author, isbn, book_id)
                )
                conn.commit()
                return conn.total_changes > 0
        except Error as e:
            print(f"Error updating book: {e}")
            return False

    def delete_book(self, book_id):
        """Delete a book by ID."""
        try:
            with self._get_connection() as conn:
                conn.execute('DELETE FROM books WHERE id = ?', (book_id,))
                conn.commit()
                return conn.total_changes > 0
        except Error as e:
            print(f"Error deleting book: {e}")
            return False

    def get_book_by_id(self, book_id):
        """Retrieve a single book by ID."""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute('SELECT id, title, author, isbn FROM books WHERE id = ?', (book_id,))
                row = cursor.fetchone()
                if row:
                    return {'id': row[0], 'title': row[1], 'author': row[2], 'isbn': row[3]}
                return None
        except Error as e:
            print(f"Error fetching book: {e}")
            return None

    def is_isbn_unique(self, isbn, exclude_book_id=None):
        """Check if ISBN is unique, excluding the given book_id if provided."""
        try:
            with self._get_connection() as conn:
                query = 'SELECT COUNT(*) FROM books WHERE isbn = ?'
                params = (isbn,)
                if exclude_book_id:
                    query += ' AND id != ?'
                    params = (isbn, exclude_book_id)
                cursor = conn.execute(query, params)
                return cursor.fetchone()[0] == 0
        except Error as e:
            print(f"Error checking ISBN uniqueness: {e}")
            return False


# Business Logic Layer
class BookService:
    def __init__(self):
        self.db = BookDatabase()

    def get_books(self):
        """Get all books."""
        return self.db.get_all_books()

    def create_book(self, title, author, isbn):
        """Create a new book with validation."""
        if not title or not author:
            return {"error": "Title and author are required"}, 400
        if len(title) > 100 or len(author) > 100:
            return {"error": "Title and author must be less than 100 characters"}, 400
        if isbn and (not isbn.isalnum() or len(isbn) > 13):
            return {"error": "ISBN must be alphanumeric and up to 13 characters"}, 400
        if isbn and not self.db.is_isbn_unique(isbn):
            return {"error": "ISBN must be unique"}, 409

        book_id = self.db.add_book(title, author, isbn)
        if book_id:
            return {"message": "Book added successfully", "id": book_id}, 201
        return {"error": "Failed to add book"}, 500

    def update_book(self, book_id, title, author, isbn):
        """Update an existing book with validation."""
        if not title or not author:
            return {"error": "Title and author are required"}, 400
        if len(title) > 100 or len(author) > 100:
            return {"error": "Title and author must be less than 100 characters"}, 400
        if isbn and (not isbn.isalnum() or len(isbn) > 13):
            return {"error": "ISBN must be alphanumeric and up to 13 characters"}, 400
        if isbn and not self.db.is_isbn_unique(isbn, exclude_book_id=book_id):
            return {"error": "ISBN must be unique"}, 409

        success = self.db.update_book(book_id, title, author, isbn)
        if success:
            return {"message": "Book updated successfully"}, 200
        return {"error": "Book not found or update failed"}, 404

    def delete_book(self, book_id):
        """Delete a book."""
        success = self.db.delete_book(book_id)
        if success:
            return {"message": "Book deleted successfully"}, 200
        return {"error": "Book not found"}, 404

    def get_book(self, book_id):
        """Get a single book by ID."""
        book = self.db.get_book_by_id(book_id)
        if book:
            return book, 200
        return {"error": "Book not found"}, 404


# Presentation Layer
@app.route('/')
def index():
    service = BookService()
    books = service.get_books()
    return render_template('index.html', books=books)


@app.route('/add', methods=['GET', 'POST'])
def add_book():
    if request.method == 'POST':
        service = BookService()
        title = request.form.get('title', '').strip()
        author = request.form.get('author', '').strip()
        isbn = request.form.get('isbn', '').strip() or None

        result, status = service.create_book(title, author, isbn)
        if "error" in result:
            flash(result["error"], "error")
        else:
            flash(result["message"], "success")
        return redirect(url_for('index'))
    return render_template('add_book.html')


@app.route('/edit/<int:book_id>', methods=['GET', 'POST'])
def edit_book(book_id):
    service = BookService()
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        author = request.form.get('author', '').strip()
        isbn = request.form.get('isbn', '').strip() or None

        result, status = service.update_book(book_id, title, author, isbn)
        if "error" in result:
            flash(result["error"], "error")
        else:
            flash(result["message"], "success")
        return redirect(url_for('index'))

    book, status = service.get_book(book_id)
    if "error" in book:
        flash(book["error"], "error")
        return redirect(url_for('index'))
    return render_template('edit_book.html', book=book)


@app.route('/delete/<int:book_id>', methods=['POST'])
def delete_book(book_id):
    service = BookService()
    result, status = service.delete_book(book_id)
    if "error" in result:
        flash(result["error"], "error")
    else:
        flash(result["message"], "success")
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)