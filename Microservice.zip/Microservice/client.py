import requests

response = requests.get("http://127.0.0.1:5000/service")
print(response.json())  # {"message": "Hello from 1-tier Client-Server!"}
