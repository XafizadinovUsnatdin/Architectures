import requests

url = 'http://127.0.0.1:5000/analyze'
sample_text = """
Tahlilchi AI is designed to perform intelligent text analysis for various inputs using natural language processing.
"""

payload = {
    'text': sample_text
}

try:
    response = requests.post(url, json=payload)
    if response.status_code == 200:
        result = response.json()['result']
        print("✔ AI Analysis Result:")
        print("Summary:", result['summary'])
        print("Keywords:", ", ".join(result['keywords']))
        print("Sentiment:", result['sentiment'])
    else:
        print("❌ Server responded with:", response.status_code, response.text)
except Exception as e:
    print("❌ Error connecting to server:", str(e))
