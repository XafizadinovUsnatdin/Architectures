from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    user_input = data.get("text", "")

    if not user_input:
        return jsonify(result="No text provided."), 400

    # Fake AI analysis: You can replace this with real NLP processing later
    keywords = random.sample(user_input.split(), min(3, len(user_input.split())))
    analysis_result = {
        "summary": f"Analyzed text with {len(user_input.split())} words.",
        "keywords": keywords,
        "sentiment": random.choice(["Positive", "Negative", "Neutral"])
    }

    return jsonify(result=analysis_result)

if __name__ == '__main__':
    app.run(debug=True)
