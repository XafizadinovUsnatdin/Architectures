# app.py
from flask import Flask, request, render_template, redirect, url_for, flash, session
import sqlite3
from sqlite3 import Error
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'tahlilchi-ai-secret-key'  # Maxfiy kalit (o‘zingiz o‘zgartirishingiz mumkin)


# Ma’lumotlar bazasini boshqarish
class Database:
    def __init__(self, db_file='tahlilchi.db'):
        self.db_file = db_file
        self._initialize_database()

    def _initialize_database(self):
        """Ma’lumotlar bazasini yaratish va users jadvalini sozlash."""
        try:
            with self._get_connection() as conn:
                conn.execute('''CREATE TABLE IF NOT EXISTS users (
                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                username TEXT NOT NULL UNIQUE,
                                password TEXT NOT NULL)''')
                conn.commit()
        except Error as e:
            print(f"Error initializing database: {e}")

    def _get_connection(self):
        return sqlite3.connect(self.db_file, check_same_thread=False)

    def add_user(self, username, password):
        """Yangi foydalanuvchi qo‘shish."""
        try:
            with self._get_connection() as conn:
                conn.execute(
                    'INSERT INTO users (username, password) VALUES (?, ?)',
                    (username, password)
                )
                conn.commit()
                return True
        except Error as e:
            print(f"Error adding user: {e}")
            return False

    def get_user(self, username):
        """Foydalanuvchini username bo‘yicha olish."""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute('SELECT * FROM users WHERE username = ?', (username,))
                row = cursor.fetchone()
                if row:
                    return {'id': row[0], 'username': row[1], 'password': row[2]}
                return None
        except Error as e:
            print(f"Error fetching user: {e}")
            return None


# Marshrutlar
@app.route('/')
def index():
    if 'username' in session:
        return render_template('index.html', username=session['username'])
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        if not username or not password:
            flash('Username and password are required!', 'error')
            return redirect(url_for('register'))

        if len(username) < 3 or len(password) < 6:
            flash('Username must be at least 3 characters and password at least 6 characters!', 'error')
            return redirect(url_for('register'))

        db = Database()
        if db.get_user(username):
            flash('Username already exists!', 'error')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        if db.add_user(username, hashed_password):
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Registration failed. Try again.', 'error')
            return redirect(url_for('register'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        if not username or not password:
            flash('Username and password are required!', 'error')
            return redirect(url_for('login'))

        db = Database()
        user = db.get_user(username)
        if user and check_password_hash(user['password'], password):
            session['username'] = username
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password!', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)