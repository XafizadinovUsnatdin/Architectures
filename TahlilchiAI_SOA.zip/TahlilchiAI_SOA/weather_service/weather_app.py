# weather_service/weather_app.py
from flask import Flask, jsonify
import sqlite3
from sqlite3 import Error

app = Flask(__name__)

# Ma’lumotlar bazasi
class WeatherDatabase:
    def __init__(self, db_file='weather.db'):
        self.db_file = db_file
        self._initialize_database()

    def _initialize_database(self):
        """Ob-havo ma’lumotlari jadvalini yaratish."""
        try:
            with self._get_connection() as conn:
                conn.execute('''CREATE TABLE IF NOT EXISTS weather (
                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                city TEXT NOT NULL UNIQUE,
                                temp REAL NOT NULL)''')
                # Test ma’lumotlari qo‘shish
                conn.execute('INSERT OR IGNORE INTO weather (city, temp) VALUES (?, ?)', ('Tashkent', 25))
                conn.execute('INSERT OR IGNORE INTO weather (city, temp) VALUES (?, ?)', ('Samarkand', 22))
                conn.execute('INSERT OR IGNORE INTO weather (city, temp) VALUES (?, ?)', ('Karakalpakstan', 20))
                conn.execute('INSERT OR IGNORE INTO weather (city, temp) VALUES (?, ?)', ('Nukus', 21))

                conn.commit()
        except Error as e:
            print(f"Error initializing database: {e}")

    def _get_connection(self):
        return sqlite3.connect(self.db_file, check_same_thread=False)

    def get_weather(self, city):
        """Shahar bo‘yicha ob-havo ma’lumotlarini olish."""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute('SELECT city, temp FROM weather WHERE city = ?', (city,))
                row = cursor.fetchone()
                if row:
                    return {'city': row[0], 'temp': row[1]}
                return None
        except Error as e:
            print(f"Error fetching weather: {e}")
            return None

# REST API marshrutlari
@app.route('/weather/<city>', methods=['GET'])
def get_weather(city):
    db = WeatherDatabase()
    weather_data = db.get_weather(city.capitalize())  # Shahar nomini katta harf bilan boshlash
    if weather_data:
        return jsonify(weather_data)
    return jsonify({'error': 'City not found'}), 404

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)