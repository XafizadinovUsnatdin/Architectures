# notification_service/notification_app.py
from flask import Flask, render_template, request, flash, redirect, url_for
import requests

app = Flask(__name__)
app.secret_key = 'tahlilchi-ai-notification-secret'

WEATHER_SERVICE_URL = 'http://localhost:5000/weather/'

# Notification logika
def get_weather_notification(city):
    """Weather Service’dan ma’lumot olish va xabar yaratish."""
    try:
        response = requests.get(f'{WEATHER_SERVICE_URL}{city}')
        if response.status_code == 200:
            data = response.json()
            return f"Today's temperature in {data['city']} is {data['temp']}°C"
        return f"Could not fetch weather data for {city}"
    except requests.RequestException as e:
        print(f"Error calling Weather Service: {e}")
        return "Weather service unavailable"

# Marshrutlar
@app.route('/', methods=['GET', 'POST'])
def index():
    notification = None
    if request.method == 'POST':
        city = request.form.get('city', '').strip()
        if not city:
            flash('Please enter a city name!', 'error')
        else:
            notification = get_weather_notification(city)
            flash(notification, 'success')
        return redirect(url_for('index'))
    return render_template('index.html', notification=notification)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)