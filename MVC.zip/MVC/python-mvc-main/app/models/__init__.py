# flake8: noqa: F401
"""Models package."""

from .book import Book
