import json
from typing import Optional


class Book:
    """Handle the books."""

    FILE_PATH = "books.json"

    @classmethod
    def load_books(cls):
        """JSON fayldan kitoblarni yuklash."""
        try:
            with open(cls.FILE_PATH, "r", encoding="utf-8") as f:
                return {int(k): v for k, v in json.load(f).items()}
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    @classmethod
    def save_books(cls, books):
        """Kitoblarni JSON faylga saqlash."""
        with open(cls.FILE_PATH, "w", encoding="utf-8") as f:
            json.dump(books, f, indent=4, ensure_ascii=False)

    books = None  # Dastlab None qilib qo'yamiz

    def __init__(self, name: str, price: int):
        """Init."""
        if Book.books is None:
            Book.books = Book.load_books()

        self.name = name
        self.price = price
        self.id: Optional[int] = None

    @property
    def last_id(self):
        """Return the last ID or 1."""
        return max(self.books.keys(), default=0)

    def save(self):
        """Save the book."""
        if not self.id:
            self.id = self.last_id + 1
        self.books[self.id] = {"name": self.name, "price": self.price}
        self.save_books(self.books)

    def delete(self):
        """Delete the book."""
        if self.id and self.id in self.books:
            del self.books[self.id]
            self.save_books(self.books)

    @classmethod
    def get(cls, id: int) -> Optional["Book"]:
        """Get a book from the given ID."""
        if cls.books is None:
            cls.books = cls.load_books()

        db_book = cls.books.get(id)
        if db_book:
            book = Book(**db_book)
            book.id = id
            return book
        return None

    @classmethod
    def list(cls):
        """List the books."""
        if cls.books is None:
            cls.books = cls.load_books()

        return [Book.get(id) for id in cls.books]

    def __str__(self):
        """Return the book details."""
        return f"id: {self.id}\nname: {self.name}\nprice: {self.price}"
