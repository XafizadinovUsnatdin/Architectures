"""Blank command."""

from .abc import Command


class Blank(Command):
    """Blank command."""
